module.exports = {
    secretOrKey: 'MEgCQQDr+wxm3dyV3GKQkb2dZF+aLUyeLh+iKKAv9ouzn/g+gTMu455rtwXCHiGpTHN8gqY5oybDCvht15huffJ0mRDTAgMBAAE='
}